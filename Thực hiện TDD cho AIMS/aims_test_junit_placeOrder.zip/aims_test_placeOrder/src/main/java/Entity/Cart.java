package Entity;

import java.util.ArrayList;
import java.util.List;

public class Cart {
    private int id;
    private  String cartCode;
    private String owner;
    private  String cvvCode;
    private  String dateExpired;
    private List<Media> medias ;



}
